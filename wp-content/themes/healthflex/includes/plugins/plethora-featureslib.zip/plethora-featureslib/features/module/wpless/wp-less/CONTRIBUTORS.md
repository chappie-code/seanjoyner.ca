# `wp-less` Contributors

These people have contributed code to improve the quality and features of the WordPress plugin.  
They are listed in an alphabetical order.

* [Drew Geraets](https://github.com/drewgeraets)
 * SSL URL issue
* [Mark Fabrizio](https://github.com/fabrizim)
 * Caching and Garbage collection issues
* [Rix](https://github.com/RixTox)
 * WordPress compatibility issue
* [Sebastian Schmid](https://github.com/sebastianschmid)
 * URL resolving on old PHP version
